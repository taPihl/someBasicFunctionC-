﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public static class bitConversion
    {
        private static bool[] ConvertToBits(ulong inValue)
        {
            bool bool_start = true;
            ulong ulng_remainder = 0;
            ulong ulng_temp = 0;
            sbyte i = 0;
            ulong ulng_quotient = inValue;
            bool[] boolArr_returnValue = new bool[64];

            while (bool_start == true)
            {
                if (ulng_quotient == 5)
                {
                    boolArr_returnValue[i] = true;
                    boolArr_returnValue[i + 2] = true;
                    bool_start = false;
                }
                else if (ulng_quotient == 4)
                {
                    boolArr_returnValue[i + 2] = true;
                    bool_start = false;
                }
                else if (ulng_quotient == 3)
                {
                    boolArr_returnValue[i] = true;
                    boolArr_returnValue[i + 1] = true;
                    bool_start = false;
                }
                else if (ulng_quotient == 2)
                {
                    boolArr_returnValue[i + 1] = true;
                    bool_start = false;
                }
                else if (ulng_quotient == 1)
                {
                    boolArr_returnValue[i] = true;
                    bool_start = false;
                }
                else if (ulng_quotient == 0)
                {
                    bool_start = false;
                }
                else
                {
                    ulng_remainder = ulng_quotient % 2;
                    if (ulng_remainder == 1)
                    {
                        boolArr_returnValue[i] = true;
                        ulng_temp = ulng_quotient - 1;
                        ulng_quotient = ulng_temp / 2;
                        i++;
                    }
                    else if (ulng_remainder == 0)
                    {
                        ulng_quotient = ulng_quotient / 2;
                        i++;
                    }
                }
            }
            return boolArr_returnValue;
        }

        private static bool[] ConvertLargerArrayToSmaller(bool[] inBoolArr_value, byte inByte_bitCount = 16)
        {
            byte i;
            bool[] boolArr_retVal8 = new bool[8];
            bool[] boolArr_retVal16 = new bool[16];
            bool[] boolArr_retVal32 = new bool[32];

            if(inByte_bitCount == 8)
            {
                for (i = 0; i < 8; i++)
                {
                    boolArr_retVal8[i] = inBoolArr_value[i];
                }
                return boolArr_retVal8;
            }
            else if (inByte_bitCount == 16)
            {
                for (i = 0; i < 16; i++)
                {
                    boolArr_retVal16[i] = inBoolArr_value[i];
                }
                return boolArr_retVal16;
            }
            else if (inByte_bitCount == 32)
            {
                for (i = 0; i < 32; i++)
                {
                    boolArr_retVal32[i] = inBoolArr_value[i];
                }
                return boolArr_retVal32;
            }
            else
            {
                return boolArr_retVal8;
            }
        }

        public static bool[] IntegerToBits(byte inValue)
        {
            bool[] boolArr_retValPri = new bool[64];
            bool[] boolArr_retValSec = new bool[8];

            boolArr_retValPri = ConvertToBits(inValue);
            boolArr_retValSec = ConvertLargerArrayToSmaller(boolArr_retValPri, 8);
            return boolArr_retValSec;
        }

        public static bool[] IntegerToBits(ushort inValue)
        {
            bool[] boolArr_retValPri = new bool[64];
            bool[] boolArr_retValSec = new bool[16];

            boolArr_retValPri = ConvertToBits(inValue);
            boolArr_retValSec = ConvertLargerArrayToSmaller(boolArr_retValPri, 16);
            return boolArr_retValSec;
        }

        public static bool[] IntegerToBits(uint inValue)
        {
            bool[] boolArr_retValPri = new bool[64];
            bool[] boolArr_retValSec = new bool[32];

            boolArr_retValPri = ConvertToBits(inValue);
            boolArr_retValSec = ConvertLargerArrayToSmaller(boolArr_retValPri, 32);
            return boolArr_retValSec;
        }

        public static bool[] IntegerToBits(ulong inValue)
        {
            bool[] boolArr_retValPri = new bool[64];

            boolArr_retValPri = ConvertToBits(inValue);
            return boolArr_retValPri;
        }
    }
}
