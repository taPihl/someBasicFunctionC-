﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public class meanCalculation
    {
        public static double mean(double[] inDblArr_values)
        {
            double dbl_returnValue = 0;

            for(int i = 0; i < inDblArr_values.Length; i++)
            {
                dbl_returnValue = dbl_returnValue + inDblArr_values[i];
            }

            dbl_returnValue = dbl_returnValue / inDblArr_values.Length;

            return dbl_returnValue;
        }
    }
}
