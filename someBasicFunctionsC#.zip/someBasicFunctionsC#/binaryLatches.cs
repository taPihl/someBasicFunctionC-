﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public class setResetLatch
    {
        public bool bool_status;

        public setResetLatch()
        {
            this.bool_status = false;
        }

        public bool SR(bool inBool_set, bool inBool_reset)
        {
            if (inBool_set == true && inBool_reset == false)
            {
                this.bool_status = true;
            }
            else if (inBool_set == true && inBool_reset == true)
            {
                this.bool_status = false;
            }
            else if (inBool_set == false && inBool_reset == true)
            {
                this.bool_status = false;
            }
            return this.bool_status;
        }
    }

    public class resetSetLatch
    {
        public bool bool_status;

        public resetSetLatch()
        {
            this.bool_status = false;
        }

        public bool RS(bool inBool_set, bool inBool_reset)
        {
            if (inBool_set == true && inBool_reset == false)
            {
                this.bool_status = true;
            }
            else if (inBool_set == true && inBool_reset == true)
            {
                this.bool_status = true;
            }
            else if (inBool_set == false && inBool_reset == true)
            {
                this.bool_status = false;
            }
            return this.bool_status;
        }
    }
}
