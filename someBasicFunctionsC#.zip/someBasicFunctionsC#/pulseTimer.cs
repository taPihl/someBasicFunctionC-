﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public class pulseTimer : timerElementary
    {
        edgeDetectionBinary inputEdge;
        setResetLatch status;

        public pulseTimer(bool inBool_cmdPrintStatusToConsole = false) : base(inBool_cmdPrintStatusToConsole)
        {
            this.inputEdge = new edgeDetectionBinary(true, false);
            this.status = new setResetLatch();
        }

        public bool RunPulseCyclic(bool inBool_command, int inInt_setTime_ms)
        {
            bool bool_edge = this.inputEdge.BinaryEdgeDetection(inBool_command);
            bool bool_status = this.status.SR(bool_edge, this.bool_elapsed);

            if(bool_status == true)
            {
                this.RunCyclic(true, false, inInt_setTime_ms);
            }
            else
            {
                this.RunCyclic(false, true);
            }
            return this.bool_running;
        }
    }
}
