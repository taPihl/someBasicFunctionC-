﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Collections;
using BasicFunctions;

class program
{
    public static void Main()
    {
        timerElementary myTimer = new timerElementary(true);
        Hashtable myTimerStatus = new Hashtable();
        //myTimer.RunCyclic(true, 1000);


        while (true)
        {
            myTimer.RunCyclic(true, false, 1000);            
        }

    }
}
