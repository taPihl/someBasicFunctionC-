﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    class onDelayTimer : timerElementary
    {
        public onDelayTimer(bool inBool_cmdPrintStatusToConsole = false) : base(inBool_cmdPrintStatusToConsole)
        {
        }

        public bool RunOnDelayCyclic(bool inBool_command, int inInt_setTime_ms)
        {
            if(inBool_command == true)
            {
                this.RunCyclic(true, false, inInt_setTime_ms);
            }
            else
            {
                this.RunCyclic(false, true);
            }
            return this.bool_elapsed;
        }
    }
}
