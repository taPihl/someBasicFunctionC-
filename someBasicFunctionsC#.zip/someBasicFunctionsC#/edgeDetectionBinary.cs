﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public class edgeDetectionBinary
    {
        private bool bool_stPrevious;
        public bool bool_typePositive;
        public bool bool_typeNegative;

        public edgeDetectionBinary(bool inBool_typePositive, bool inBool_typeNegative)
        {
            this.bool_typePositive = inBool_typePositive;
            this.bool_typeNegative = inBool_typeNegative;
            this.bool_stPrevious = false;
        }

        public bool BinaryEdgeDetection(bool inBool_signal)
        {
            bool outbool_status = false;

            if(inBool_signal == false && this.bool_stPrevious == true && this.bool_typeNegative == true)
            {
                outbool_status = true;
            }
            else if (inBool_signal == true && this.bool_stPrevious == false && this.bool_typePositive == true)
            {
                outbool_status = true;
            }
            this.bool_stPrevious = inBool_signal;
            return outbool_status;
        }
    }
}
