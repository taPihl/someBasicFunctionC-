﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicFunctions
{
    public class timerElementary
    {
        public bool bool_running;
        public bool bool_elapsed;
        public bool bool_initialized;
        private bool bool_printStatus;
        private bool bool_memory_1;
        private int int_runTime_ms;
        private int int_elapsedTime_ms;
        private int int_timePrev_ms;
        private DateTime Dt;
        public Hashtable hshTbl_status = new Hashtable();

        public timerElementary(bool inBool_cmdPrintStatus)
        {
            this.bool_running = false;
            this.bool_elapsed = false;
            this.bool_initialized = false;
            this.bool_printStatus = inBool_cmdPrintStatus;
            this.bool_memory_1 = false;
            this.int_runTime_ms = 0;
            this.int_elapsedTime_ms = 0;
            this.int_timePrev_ms = 0;
            this.hshTbl_status.Add("running", false);
            this.hshTbl_status.Add("elapsed", false);
            this.hshTbl_status.Add("initialized", false);
            this.hshTbl_status.Add("elapsed time", this.int_elapsedTime_ms);
            this.hshTbl_status.Add("runtime", this.int_runTime_ms);
        }
        private void Initialize(int inInt_setTime_ms)
        {
            this.bool_running = false;
            this.bool_elapsed = false;
            this.bool_initialized = true;
            this.int_runTime_ms = inInt_setTime_ms;
            this.int_elapsedTime_ms = 0;
            this.int_timePrev_ms = 0;
        }
        private void GetElapsedTime()
        {
            int int_difference_ms;
            this.Dt = DateTime.Now;
            int int_currentTime_ms = this.Dt.Millisecond;
            
            if (int_currentTime_ms > this.int_timePrev_ms)
            {
                int_difference_ms = int_currentTime_ms - this.int_timePrev_ms;
            }
            else if (this.int_timePrev_ms > int_currentTime_ms)
            {
                int_difference_ms = 1000 - this.int_timePrev_ms + int_currentTime_ms;
            }
            else
            {
                int_difference_ms = 0;
            }
            this.int_elapsedTime_ms = this.int_elapsedTime_ms + int_difference_ms;
            this.int_timePrev_ms = int_currentTime_ms;
        }
        private void QueryStatus()
        {
            if(this.bool_running == true)
            {
                this.GetElapsedTime();
                if (this.int_elapsedTime_ms >= this.int_runTime_ms)
                {
                    this.bool_elapsed = true;
                    this.bool_running = false;
                }
            }
        }
        private void WriteStatus()
        {
            this.hshTbl_status["running"] = this.bool_running;
            this.hshTbl_status["elapsed"] = this.bool_elapsed;
            this.hshTbl_status["initialized"] = this.bool_initialized;
            this.hshTbl_status["elapsed time"] = this.int_elapsedTime_ms;
            this.hshTbl_status["runtime"] = this.int_runTime_ms;
        }
        private void PrintStatus()
        {
            foreach (DictionaryEntry de in this.hshTbl_status)
            {
                Console.WriteLine("Key: {0}, Value: {1}", de.Key, de.Value);
            }
            Console.WriteLine("");
        }
        public void RunCyclic(bool inBool_startCmd = false, bool inBool_stopCommand = false, int inInt_setTime_ms = 0)
        {
            if(inBool_stopCommand == false)
            {
                if (inBool_startCmd == true && this.bool_running == false)
                {
                    if(this.bool_initialized == false)
                    {
                        this.Initialize(inInt_setTime_ms);
                        this.bool_running = true;
                    }
                }
                this.QueryStatus();
            }
            else
            {
                this.Initialize(0);
                this.bool_initialized = false;
            }

            this.WriteStatus();
            if(this.bool_printStatus == true)
            {
                this.PrintStatus();
            }            
        }
    }
}
